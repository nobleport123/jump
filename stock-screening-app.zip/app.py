
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import time

# Simulate real-time stock data
def generate_mock_data():
    tickers = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA"]
    data = pd.DataFrame({
        "Ticker": tickers,
        "Price": np.random.uniform(100, 500, size=len(tickers)),
        "Sentiment": np.random.uniform(-1, 1, size=len(tickers)),
        "Earnings": np.random.uniform(0, 10, size=len(tickers)),
    })
    return data

# Streamlit app
st.set_page_config(page_title="Stock Screening App", layout="wide")

st.title("Real-Time Stock Screening Dashboard")

# Real-time updates
st.sidebar.header("Refresh Rate")
refresh_rate = st.sidebar.slider("Refresh interval (seconds)", 1, 10, 5)

# Real-time mock data
placeholder = st.empty()
while True:
    with placeholder.container():
        data = generate_mock_data()

        # Layout with columns
        col1, col2 = st.columns([2, 1])

        # Column 1: Data table and charts
        with col1:
            st.write("### Stock Data")
            st.dataframe(data)

            # Line Chart for Price Trends
            st.write("### Price Trends (Simulated)")
            for ticker in data["Ticker"]:
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=pd.date_range("2024-12-01", periods=30, freq="D"),
                    y=np.random.uniform(100, 500, size=30),
                    mode="lines",
                    name=ticker,
                ))
                fig.update_layout(title=f"{ticker} Price Trend", xaxis_title="Date", yaxis_title="Price (USD)")
                st.plotly_chart(fig, use_container_width=True)

        # Column 2: Sector Analysis
        with col2:
            st.write("### Sentiment Analysis")
            sentiment_pie = px.pie(data, values="Sentiment", names="Ticker", title="Sentiment Distribution")
            st.plotly_chart(sentiment_pie, use_container_width=True)

    # Real-time refresh
    time.sleep(refresh_rate)
