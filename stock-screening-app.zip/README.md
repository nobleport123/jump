
# Stock Screening App

This is a real-time stock screening dashboard built with Streamlit. It provides simulated data for stock prices, earnings, and sentiment analysis.

## Features
- Real-time updates with adjustable refresh intervals
- Interactive charts for stock price trends
- Sentiment distribution visualized with a pie chart

## How to Run the App Locally
1. Clone this repository:
   ```bash
   git clone https://github.com/your-username/stock-screening-app.git
   cd stock-screening-app
   ```
2. Install the dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the app:
   ```bash
   streamlit run app.py
   ```
4. Open the app in your browser at `http://localhost:8501`.

## Deployment
This app is ready to deploy on [Streamlit Cloud](https://streamlit.io/cloud).
